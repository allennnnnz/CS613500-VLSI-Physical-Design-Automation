#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <unordered_map>
#include <string>
#include <algorithm>
#include <cmath>
#include <ctime>
#include "FM.hpp"

int main(int argc, char *argv[]) {
    if(argc < 3 || argc > 4) {
        std::cout << "Usage: " << argv[0] << " <INPUT> <OUTPUT> [WAY]" << std::endl;
        std::cout << "  WAY: 2 for 2-way, 4 for 4-way (default: 4)" << std::endl;
        return -1;
    }
    int way = 4;
    if (argc == 4) {
        way = std::atoi(argv[3]);
        if (way != 2 && way != 4) {
            std::cerr << "Invalid WAY (must be 2 or 4)." << std::endl;
            return -1;
        }
    }

    // Run FM according to WAY
    FM fm(argv[1], argv[2], way);
    return 0;
}
