#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <unordered_map>
#include <string>
#include <algorithm>
#include <cmath>
#include <ctime>
#include "Cell.hpp"
#include <climits>

class BucketList {
public:
    std::vector<std::vector<Cell*>> buckets;//buckets[i]存gain值相同的cell
    std::unordered_map<Cell*, std::pair<int, int>> cells;
    /*
    •	用來快速定位每個 Cell 在 buckets 裡的位置
	•	key：Cell*（Cell 的指標）
	•	value：std::pair<int,int>，記錄 Cell 在哪個桶以及桶內位置
    */
    int maxPinNum;//cell身上最多有幾條net可能就會是最大gain
    int maxGain;
    long size;//目前這個set裡的cell size總和

    BucketList();
    void set_bucket_size(int mpn);//如果最大gain值增加了 bucket list也要跟著變大
    void insert_cell(Cell* cell);
    void remove_cell(Cell* cell);
    void update_cell(Cell* cell);
    int gain_to_index(int gain);
    void print(char setName);
    Cell* get_top_kth_cell(int k);
};
