#include "FM.hpp"
#include <climits>
#include <utility>
#include <cmath>
#include <array>

FM::FM(){};

FM::FM(std::string filename, std::string outFile) {
    // default to 4-way to preserve previous behavior in this branch
    FM(filename, outFile, 4);
}

FM::FM(std::string filename, std::string outFile, int way) {
    // Start timer
    startAll = clock();
    std::cout << (way == 4 ? "FM (4-way via recursive 2-way) starts" : "FM (2-way) starts") << std::endl << std::endl;

    // Read inputs
    read_inputs(filename);
    std::cout << "read finished" << std::endl;

    // Set runtime
    set_runtime();

    if (way == 4) {
        // Run 4-way partition pipeline (does not mutate global nets' counts)
        partition_4way(outFile);
    } else {
        // Run original global 2-way pipeline
        setA.set_bucket_size(maxPinNum);
        setB.set_bucket_size(maxPinNum);
        initial_partition_v2();

        maxPartialSum = 1;
        pass_num = 1;
        while(maxPartialSum > 0) {
            run_pass();
            pass_num++;
        }
        write_result(outFile);
    }

    std::cout << "FM ends" << std::endl << std::endl;

    // Print time info
    print_time_info();
}



void FM::read_inputs(std::string filename) {
    startIO = clock();
    std::ifstream fin(filename);
    if (!fin.is_open()) {
        std::cerr << "Cannot open file: " << filename << std::endl;
        return;
    }

    std::string tag;
    int numCells = 0, numNets = 0;
    maxPinNum = 0;  // ✅ 確保初始化

    // ==========================================
    // 🟦 讀取 Cell 區塊
    // ==========================================
    fin >> tag >> numCells;   // 讀 NumCells 12752
    std::cout << "[Info] NumCells = " << numCells << std::endl;

    for (int i = 0; i < numCells; i++) {
        fin >> tag; // "Cell"
        std::string cellName;
        int size;
        fin >> cellName >> size;
        cells[cellName] = Cell(cellName, size);
    }

    // 跳過空白或換行（避免空行卡住）
    fin >> std::ws;

    // ==========================================
    // 🟩 讀取 Net 區塊
    // ==========================================
    fin >> tag >> numNets;   // 讀 NumNets 14111
    std::cout << "[Info] NumNets = " << numNets << std::endl;

    for (int i = 0; i < numNets; i++) {
        fin >> tag;  // "Net"
        std::string netName;
        int cellCount;
        fin >> netName >> cellCount;

        std::vector<Cell*> netCells;
        netCells.reserve(cellCount); // ✅ 效率更好

        for (int j = 0; j < cellCount; j++) {
            fin >> tag;       // "Cell"
            std::string cellName;
            fin >> cellName;  // e.g. C12704

            // 建立 cell 與 net 的雙向關係
            netCells.push_back(&cells[cellName]);
            cells[cellName].add_net(&nets[netName]);

            // 更新最大 pin 數
            if (cells[cellName].pinNum > maxPinNum)
                maxPinNum = cells[cellName].pinNum;
        }

        nets[netName] = Net(netName, netCells);
    }

    timeIO = (double)(clock() - startIO) / CLOCKS_PER_SEC;

    std::cout << "[Cells loaded] " << cells.size() << std::endl;
    std::cout << "[Nets loaded] " << nets.size() << std::endl;
    std::cout << "[Max pin num] " << maxPinNum << std::endl;
}

void FM::print_nets(){
    for(auto net : nets) {
        net.second.print();
    }
};

void FM::print_sets() {
    setA.print('A');
    setB.print('B');
}

void FM::print_selected_base_cells() {
    std::cout << "Selected base cells(" << selectedBaseCells.size() << "): ";
    for(int i = 0; i < selectedBaseCells.size(); i++) {
        std::cout << selectedBaseCells[i]->name << "[" << maxGains[i] << "] ";
    }
    std::cout << std::endl;
}

void FM::pause() {
    std::cout << "----------------------Press Enter to continue---------------------" << std::endl;
    std::cin.ignore();
}

bool FM::is_balanced(long sizeA, long sizeB) {
    double total = sizeA + sizeB;
    if (total == 0) return true;  // 避免除以零
    double ratio = sizeA / total;
    return (ratio >= 0.45 && ratio <= 0.55);
}

bool FM::is_balanced(long sizeA, long sizeB, double lower, double upper) {
    double total = sizeA + sizeB;
    if (total == 0) return true;
    double ratio = sizeA / total;
    return (ratio >= lower && ratio <= upper);
}

void FM::initial_partition() {
    // Variables declaration
    long sizeA = 0, sizeB = 0;
    std::vector<Cell> sortedCells;

    // Push all cells into a vector
    for(auto cp : cells) {
        sortedCells.push_back(cp.second);//取到cell物件
        sizeA += cp.second.sizeA;
    }

    // Sort the vector by sizeB (large to small)
    std::sort(sortedCells.begin(), sortedCells.end(), [](Cell a, Cell b) { return a.sizeB < b.sizeB; });

    // Assign cell with smaller sizeB to setB until balanced
    while(!is_balanced(sizeA, sizeB)) {
        Cell c = sortedCells.back();
        sortedCells.pop_back();
        cells[c.name].inSetA = false;
        sizeA -= c.sizeA;
        sizeB += c.sizeB;
    }

    // Calculate number of cells in each set in each net
    for(auto& np : nets) {
        np.second.calc_num_in_set();
    }

    // Initialize gain of each cell
    for(auto& cp : cells) {
        cp.second.calc_gain();
    }

    // Initialize bucket lists
    for(auto& cp : cells) {
        if(cp.second.inSetA) {
            setA.insert_cell(&cp.second);
        } else {
            setB.insert_cell(&cp.second);
        }
    }

    std::cout << "INITIAL PARTITION CUT SIZE: " << calc_cut_size() << std::endl << std::endl;
}

void FM::initial_partition_v2() {
    // Variables declaration
    long sizeA = 0, sizeB = 0;
    std::vector<Cell> sortedCells;

    // Push all cells into a vector
    std::cout << "CELL NUM: " << cells.size() << std::endl;
    for(auto cp : cells) {
        sortedCells.push_back(cp.second);
        sizeA += cp.second.sizeA;
    }


    // Sort the vector by sizeB (small to large)
    std::sort(sortedCells.begin(), sortedCells.end(), [](Cell a, Cell b) { return a.sizeB < b.sizeB; });


    // Assign cell with bigger sizeB to setB until balanced
    while(!is_balanced(sizeA, sizeB)) {
        Cell c = sortedCells.back();
        sortedCells.pop_back();
        cells[c.name].inSetA = false;
        sizeA -= c.sizeA;
        sizeB += c.sizeB;
    }

    std::cout << "BEFORE balance "<< std::endl;

    for(int i = 0; i < cells.size(); i++) {
        Cell c = sortedCells.back();
        sortedCells.pop_back();
        cells[c.name].inSetA = false;
        sizeA -= c.sizeA;
        sizeB += c.sizeB;
        if(!is_balanced(sizeA, sizeB)) {
            cells[c.name].inSetA = true;
            sizeA += c.sizeA;
            sizeB -= c.sizeB;
            break;
        }
    }

    std::cout << "AFTER balance "<< std::endl;

    // Calculate number of cells in each set in each net
    for(auto& np : nets) {
        np.second.calc_num_in_set();
    }

    // Initialize gain of each cell
    for(auto& cp : cells) {
        cp.second.calc_gain();
    }

    // Initialize bucket lists
    for(auto& cp : cells) {
        if(cp.second.inSetA) {
            setA.insert_cell(&cp.second);
        } else {
            setB.insert_cell(&cp.second);
        }
    }

    std::cout << "INITIAL PARTITION CUT SIZE: " << calc_cut_size() << std::endl << std::endl;
}

bool FM::select_base_cell() {
    int ka = 1, kb = 1;
    bool found = false;
    while(!found && (ka <= setA.cells.size() || kb <= setB.cells.size())) {
        Cell* a, *b;

        if(ka <= setA.cells.size()) {
            a = setA.get_top_kth_cell(ka);
        } else {
            a = nullptr;
        }
        if(kb <= setB.cells.size()) {
            b = setB.get_top_kth_cell(kb);
        } else {
            b = nullptr;
        }

        if(a && a->isLocked) {
            a = nullptr;
        }
        if(b && b->isLocked) {
            b = nullptr;
        }

        if(a && b) {
            if(a->gain > b->gain) {
                baseCell = a;
                ka++;
                found = is_balanced(setA.size - baseCell->sizeA, setB.size + baseCell->sizeB);
            } else {
                baseCell = b;
                kb++;
                found = is_balanced(setA.size + baseCell->sizeA, setB.size - baseCell->sizeB);
            }
        } else if(a) {
            baseCell = a;
            ka++;
            found = is_balanced(setA.size - baseCell->sizeA, setB.size + baseCell->sizeB);
        } else if(b) {
            baseCell = b;
            kb++;
            found = is_balanced(setA.size + baseCell->sizeA, setB.size - baseCell->sizeB);
        } else {
            baseCell = nullptr;
            ka++;
            kb++;
        }
    }
    return found;
}

bool FM::select_base_cell_v2() {
    // Reset base cell
    baseCell = nullptr;

    // Variables declaration
    int ka = 1, kb = 1;
    Cell *ca = nullptr, *cb = nullptr;
    bool found = false;

    // Find max gain cell of setA
    while(ka <= setA.cells.size()) {
        ca = setA.get_top_kth_cell(ka);
        if(ca && ca->isLocked)
            ka++;
        else
            break;
    }

    // Find max gain cell of setB
    while(kb <= setB.cells.size()) {
        cb = setB.get_top_kth_cell(kb);
        if(cb && cb->isLocked)
            kb++;
        else
            break;
    }

    // Determine base cell
    if(ca && cb) {
        if(ca->gain > cb->gain) {
            baseCell = ca;
            found = is_balanced(setA.size - baseCell->sizeA, setB.size + baseCell->sizeB);
            if(!found) {
                baseCell = cb;
                found = is_balanced(setA.size + baseCell->sizeA, setB.size - baseCell->sizeB);
            }
        } else {
            baseCell = cb;
            found = is_balanced(setA.size + baseCell->sizeA, setB.size - baseCell->sizeB);
            if(!found) {
                baseCell = ca;
                found = is_balanced(setA.size - baseCell->sizeA, setB.size + baseCell->sizeB);
            }
        }
    } else if(ca) {
        baseCell = ca;
        found = is_balanced(setA.size - baseCell->sizeA, setB.size + baseCell->sizeB);
    } else if(cb) {
        baseCell = cb;
        found = is_balanced(setA.size + baseCell->sizeA, setB.size - baseCell->sizeB);
    } else {
        baseCell = nullptr;
        found = false;
    }

    // Return found
    return found;
}

bool FM::select_base_cell_v3() {
    // Reset base cell
    baseCell = nullptr;

    // Variables declaration
    Cell *ca = nullptr, *cb = nullptr;
    int ka = 1, kb = 1;
    bool found = false;
    
    // Find base cell
    while(!found && (ka <= setA.cells.size() || kb <= setB.cells.size())) {
        // Find max gain cell of setA
        while(ka <= setA.cells.size()) {
            ca = setA.get_top_kth_cell(ka);
            if(ca && ca->isLocked)
                ka++;
            else
                break;
        }

        // Find max gain cell of setB
        while(kb <= setB.cells.size()) {
            cb = setB.get_top_kth_cell(kb);
            if(cb && cb->isLocked)
                kb++;
            else
                break;
        }

        // Determine base cell
        if(ca && cb) {
            if(ca->gain > cb->gain) {
                baseCell = ca;
                found = is_balanced(setA.size - baseCell->sizeA, setB.size + baseCell->sizeB);
                ka++;
                if(!found) {
                    baseCell = cb;
                    found = is_balanced(setA.size + baseCell->sizeA, setB.size - baseCell->sizeB);
                    kb++;
                }
            } else {
                baseCell = cb;
                found = is_balanced(setA.size + baseCell->sizeA, setB.size - baseCell->sizeB);
                kb++;
                if(!found) {
                    baseCell = ca;
                    found = is_balanced(setA.size - baseCell->sizeA, setB.size + baseCell->sizeB);
                    ka++;
                }
            }
        } else if(ca) {
            baseCell = ca;
            found = is_balanced(setA.size - baseCell->sizeA, setB.size + baseCell->sizeB);
            ka++;
        } else if(cb) {
            baseCell = cb;
            found = is_balanced(setA.size + baseCell->sizeA, setB.size - baseCell->sizeB);
            kb++;
        } else {
            ka++;
            kb++;
            baseCell = nullptr;
            found = false;
        }
    }

    // Return found
    return found;
}

bool FM::select_base_cell_v4() {
    // Reset base cell
    baseCell = nullptr;

    // Variables declaration
    Cell *ca = nullptr, *cb = nullptr;
    int ka = 1, kb = 1;
    bool found = false;
    bool fromA = true;

    // Find base cell
    while(!found && (ka <= setA.cells.size() || kb <= setB.cells.size())) {
        if(fromA) {
            ca = setA.get_top_kth_cell(ka++);
            if(ca && !ca->isLocked) {
                baseCell = ca;
                found = is_balanced(setA.size - baseCell->sizeA, setB.size + baseCell->sizeB);
            }
        } else {
            cb = setB.get_top_kth_cell(kb++);
            if(cb && !cb->isLocked) {
                baseCell = cb;
                found = is_balanced(setA.size + baseCell->sizeA, setB.size - baseCell->sizeB);
            }
        }
        fromA = !fromA;
    }

    // Return found
    return found;
}

void FM::calc_max_partial_sum() {
    int max = INT_MIN, sum = 0, index = -1;
    for(int i = 0; i < maxGains.size(); i++) {
        sum += maxGains[i];
        if(sum > max) {
            max = sum;
            index = i;
        }
    }
    maxPartialSum = max;
    maxPartialSumIndex = index;
}

void FM::update_cells_gain() {
    if(baseCell->inSetA) {
        baseCell->isLocked = true;
        for(auto it = baseCell->nets.begin(); it != baseCell->nets.end(); it++) {
            if((*it)->numInSetB == 0) {
                for(auto it2 = (*it)->cells.begin(); it2 != (*it)->cells.end(); it2++) {
                    (*it2)->add_gain();
                    if((*it2)->inSetA) {
                        setA.update_cell(*it2);
                    } else {
                        setB.update_cell(*it2);
                    }
                }
            } else if((*it)->numInSetB == 1) {
                for(auto it2 = (*it)->cells.begin(); it2 != (*it)->cells.end(); it2++) {
                    if(!(*it2)->inSetA) {
                        (*it2)->sub_gain();
                        if((*it2)->inSetA) {
                            setA.update_cell(*it2);
                        } else {
                            setB.update_cell(*it2);
                        }
                    }
                }
            }
            (*it)->numInSetA--;
            (*it)->numInSetB++;
            if((*it)->numInSetA == 0) {
                for(auto it2 = (*it)->cells.begin(); it2 != (*it)->cells.end(); it2++) {
                    (*it2)->sub_gain();
                    if((*it2)->inSetA) {
                        setA.update_cell(*it2);
                    } else {
                        setB.update_cell(*it2);
                    }
                }
            } else if((*it)->numInSetA == 1) {
                for(auto it2 = (*it)->cells.begin(); it2 != (*it)->cells.end(); it2++) {
                    if((*it2)->inSetA) {
                        (*it2)->add_gain();
                        if((*it2)->inSetA) {
                            setA.update_cell(*it2);
                        } else {
                            setB.update_cell(*it2);
                        }
                    }
                }
            }
        }
        setA.remove_cell(baseCell);
        baseCell->inSetA = false;
        baseCell->calc_gain();
        baseCell->isLocked = true;
        setB.insert_cell(baseCell);
    } else {
        baseCell->isLocked = true;
        for(auto it = baseCell->nets.begin(); it != baseCell->nets.end(); it++) {
            if((*it)->numInSetA == 0) {
                for(auto it2 = (*it)->cells.begin(); it2 != (*it)->cells.end(); it2++) {
                    (*it2)->add_gain();
                    if((*it2)->inSetA) {
                        setA.update_cell(*it2);
                    } else {
                        setB.update_cell(*it2);
                    }
                }
            } else if((*it)->numInSetA == 1) {
                for(auto it2 = (*it)->cells.begin(); it2 != (*it)->cells.end(); it2++) {
                    if((*it2)->inSetA) {
                        (*it2)->sub_gain();
                        if((*it2)->inSetA) {
                            setA.update_cell(*it2);
                        } else {
                            setB.update_cell(*it2);
                        }
                    }
                }
            }
            (*it)->numInSetB--;
            (*it)->numInSetA++;
            if((*it)->numInSetB == 0) {
                for(auto it2 = (*it)->cells.begin(); it2 != (*it)->cells.end(); it2++) {
                    (*it2)->sub_gain();
                    if((*it2)->inSetA) {
                        setA.update_cell(*it2);
                    } else {
                        setB.update_cell(*it2);
                    }
                }
            } else if((*it)->numInSetB == 1) {
                for(auto it2 = (*it)->cells.begin(); it2 != (*it)->cells.end(); it2++) {
                    if(!(*it2)->inSetA) {
                        (*it2)->add_gain();
                        if((*it2)->inSetA) {
                            setA.update_cell(*it2);
                        } else {
                            setB.update_cell(*it2);
                        }
                    }
                }
            }
        }
        setB.remove_cell(baseCell);
        baseCell->inSetA = true;
        baseCell->calc_gain();
        baseCell->isLocked = true;
        setA.insert_cell(baseCell);
    }
}

void FM::reset_lock() {
    for(auto& cell : selectedBaseCells) {
        cell->isLocked = false;
    }
}

void FM::roll_back_from(int index) {
    for(int i = selectedBaseCells.size() - 1; i >= index; i--) {
        baseCell = selectedBaseCells[i];
        update_cells_gain();
    }
}

void FM::run_pass() {
    // Variables declaration
    int iteration = 0;
    bool terminate = false;

    // Select base cell and update cells gain
    while(select_base_cell()) {
        iteration++;
        maxGains.push_back(baseCell->gain);
        selectedBaseCells.push_back(baseCell);
        update_cells_gain();
        if(pass_num == 1) {
            if(iteration >= cells.size() / 2) {
                break;
            }
        } else {
            if(iteration >= cells.size() / 40) {
                break;
            }
        }
        if(((clock() - startAll) / (double) CLOCKS_PER_SEC) > runtime) {
            terminate = true;
            break;
        }
    }
    std::cout << "Iteration: " << iteration << std::endl;

    // Calculate max partial sum
    calc_max_partial_sum();
    std::cout << "Max partial sum index: " << maxPartialSumIndex << std::endl;
    std::cout << "Base cells size: " << selectedBaseCells.size() << std::endl;

    // Reset lock
    reset_lock();

    // Roll back
    if(maxPartialSum <= 0) {
        roll_back_from(0);
    } else if(maxPartialSumIndex < selectedBaseCells.size() - 1) {
        roll_back_from(maxPartialSumIndex + 1);
    }

    // Clear
    reset_lock();
    maxGains.clear();
    selectedBaseCells.clear();

    // Terminate
    if(terminate)
        maxPartialSum = INT_MIN;

    std::cout << "cut size: " << calc_cut_size() << std::endl;
    std::cout << "[Curr time] " << (clock() - startAll) / (double) CLOCKS_PER_SEC << std::endl << std::endl;
}

int FM::calc_cut_size() {
    int cutSize = 0;
    for(auto np: nets) {
        if(np.second.numInSetA > 0 && np.second.numInSetB > 0) {
            cutSize++;  
        }
    }
    return cutSize;
}

void FM::write_result(std::string filename) {
    // Start timer
    startIO = clock();

    // File operation
    std::ofstream fout;
    fout.open(filename);
    int cutSize = calc_cut_size();
    fout << "CutSize " << cutSize << std::endl;
    // fout << "// CutSize cut size" << std::endl; // optional comment line
    fout << "GroupA " << setA.cells.size() << std::endl;
    // fout << "// GroupA number of cells in GroupA" << std::endl; // optional comment line
    for(auto s: setA.cells) {
        fout << s.first->name << std::endl;
    }
    fout << "GroupB " << setB.cells.size() << std::endl;
    // fout << "// GroupB number of cells in GroupB" << std::endl; // optional comment line
    for(auto s: setB.cells) {
        fout << s.first->name << std::endl;
    }
    fout.close();

    // End timer
    timeIO += (double)(clock() - startIO) / CLOCKS_PER_SEC;

    std::cout << std::endl;
    std::cout << "[Cut size] " << cutSize << std::endl;
    std::cout << "[A size] " << setA.cells.size() << std::endl;
    std::cout << "[B size] " << setB.cells.size() << std::endl;
    std::cout << std::endl;
}

void FM::print_time_info() {
    // Calculate time
    timeTotal = (double)(clock() - startAll)/CLOCKS_PER_SEC;
    timeCPU = timeTotal - timeIO;

    // Print time
    std::cout << std::endl;
    std::cout << "[CPU time] " << timeCPU << " secs" << std::endl;
    std::cout << "[IO time] " << timeIO << " secs" << std::endl;
    std::cout << "-------------------------" << std::endl;
    std::cout << "[Total time] " << timeTotal << " secs" << std::endl;
    std::cout << std::endl;
}

void FM::set_runtime() {
    // if(cells.size() <= 100000) {
    //     runtime = 2.0;
    // } else if(cells.size() <= 200000) {
    //     runtime = 5.5;
    // } else {
    //     runtime = 18.5;
    // }
    runtime = 285.0;
}

// =============================
// 4-way via recursive 2-way
// =============================

void FM::partition_4way(std::string outFile) {
    // std::cout << "[4way] start" << std::endl;
    // Collect all cells
    std::vector<Cell*> all;
    all.reserve(cells.size());
    for (auto& kv : cells) all.push_back(&kv.second);

    // First bipartition -> P0, P1
    std::vector<Cell*> P0, P1;
    // prefer a near 50/50 split to make second-level absolute bounds feasible
    bipartition_subset(all, P0, P1, 0.49, 0.51);

    // Second level
    std::vector<Cell*> P00, P01, P10, P11;
    auto subset_sum = [](const std::vector<Cell*>& v){ long s=0; for(Cell* c: v) s += c->sizeA; return s; };
    long total = subset_sum(all);
    // helper to gently rebalance a pair of groups to meet global bounds [lower, upper]
    auto rebalance_global = [&](std::vector<Cell*>& A, std::vector<Cell*>& B, double lower, double upper){
        auto sum_vec = [&](const std::vector<Cell*>& v){ return subset_sum(v); };
        auto sort_by_size_asc = [&](std::vector<Cell*>& v){
            std::sort(v.begin(), v.end(), [](Cell* x, Cell* y){ return x->sizeA < y->sizeA; });
        };

        const long low = (long)std::ceil(lower * (double)total);
        const long high = (long)std::floor(upper * (double)total);

        long sA = sum_vec(A);
        // If A too small, pull smallest cells from B until within [low, high]
        if (sA < low) {
            sort_by_size_asc(B);
            for (size_t i = 0; i < B.size() && sA < low; ++i) {
                Cell* pick = B[i];
                long next = sA + pick->sizeA;
                // Prefer not to exceed high
                if (next <= high) {
                    A.push_back(pick);
                    sA = next;
                    B.erase(B.begin()+i);
                    --i; // adjust index after erase
                }
            }
            // If we still didn't reach low due to coarse cell sizes, allow one best-effort move
            if (sA < low && !B.empty()) {
                // move the smallest available to minimize overshoot
                sort_by_size_asc(B);
                Cell* pick = B.front();
                A.push_back(pick);
                sA += pick->sizeA;
                B.erase(B.begin());
            }
            // If overshoot happened, try push back smallest from A to B to get under high
            if (sA > high) {
                sort_by_size_asc(A);
                for (size_t i = 0; i < A.size() && sA > high; ++i) {
                    Cell* pick = A[i];
                    long next = sA - pick->sizeA;
                    if (next >= low) {
                        B.push_back(pick);
                        sA = next;
                        A.erase(A.begin()+i);
                        --i;
                    }
                }
            }
        }
        // If A too big, push smallest cells from A to B until within [low, high]
        else if (sA > high) {
            sort_by_size_asc(A);
            for (size_t i = 0; i < A.size() && sA > high; ++i) {
                Cell* pick = A[i];
                long next = sA - pick->sizeA;
                if (next >= low || sA > high) {
                    B.push_back(pick);
                    sA = next;
                    A.erase(A.begin()+i);
                    --i;
                }
            }
            // If we undershoot low due to coarse sizes, pull back from B
            if (sA < low && !B.empty()) {
                sort_by_size_asc(B);
                for (size_t i = 0; i < B.size() && sA < low; ++i) {
                    Cell* pick = B[i];
                    long next = sA + pick->sizeA;
                    if (next <= high) {
                        A.push_back(pick);
                        sA = next;
                        B.erase(B.begin()+i);
                        --i;
                    }
                }
            }
        }
        // best-effort: at this point sA is within or as close as possible given granularity
    };

    auto rebalance_four = [&](std::vector<Cell*>& A, std::vector<Cell*>& B,
                              std::vector<Cell*>& C, std::vector<Cell*>& D,
                              double lower, double upper){
        const long low = (long)std::ceil(lower * (double)total);
        const long high = (long)std::floor(upper * (double)total);
        auto sum_vec = [&](const std::vector<Cell*>& v){ return subset_sum(v); };
        auto pop_smallest = [&](std::vector<Cell*>& v)->Cell*{
            if (v.empty()) return nullptr;
            size_t mi = 0; long ms = v[0]->sizeA;
            for (size_t i = 1; i < v.size(); ++i) if (v[i]->sizeA < ms) { ms = v[i]->sizeA; mi = i; }
            Cell* ret = v[mi]; v.erase(v.begin()+mi); return ret;
        };
        auto push_cell = [&](std::vector<Cell*>& v, Cell* c){ if (c) v.push_back(c); };

        std::array<std::vector<Cell*>*,4> parts = {&A,&B,&C,&D};
        std::array<long,4> sizes = {sum_vec(A), sum_vec(B), sum_vec(C), sum_vec(D)};
        int guard = 0;
        while (guard++ < 10000) {
            // find most overfull and most underfull
            int idx_hi = -1, idx_lo = -1; long over = 0, under = 0;
            for (int i = 0; i < 4; ++i) {
                if (sizes[i] - high > over) { over = sizes[i] - high; idx_hi = i; }
                if (low - sizes[i] > under) { under = low - sizes[i]; idx_lo = i; }
            }
            if (idx_hi == -1 || idx_lo == -1) break; // all within bounds
            // move one smallest cell from hi to lo
            Cell* moved = pop_smallest(*parts[idx_hi]);
            if (!moved) break;
            sizes[idx_hi] -= moved->sizeA;
            push_cell(*parts[idx_lo], moved);
            sizes[idx_lo] += moved->sizeA;
            // if no improvement possible due to granularity, the loop will end by guard
        }
    };
    if (!P0.empty()) {
        double f0 = (double)subset_sum(P0) / (double)total;
        // relative bounds inside P0 to hit global [0.225, 0.275]
        double lower0 = 0.225 / std::max(f0, 1e-12);
        double upper0 = 0.275 / std::max(f0, 1e-12);
        // clip to [0,1] while preserving feasibility
        lower0 = std::max(0.0, std::min(1.0, lower0));
        upper0 = std::max(0.0, std::min(1.0, upper0));
        if (lower0 > upper0) std::swap(lower0, upper0);
        bipartition_subset(P0, P00, P01, lower0, upper0);
        // enforce global window on the pair (P00,P01)
        rebalance_global(P00, P01, 0.225, 0.275);
    }
    if (!P1.empty()) {
        double f1 = (double)subset_sum(P1) / (double)total;
        double lower1 = 0.225 / std::max(f1, 1e-12);
        double upper1 = 0.275 / std::max(f1, 1e-12);
        lower1 = std::max(0.0, std::min(1.0, lower1));
        upper1 = std::max(0.0, std::min(1.0, upper1));
        if (lower1 > upper1) std::swap(lower1, upper1);
        bipartition_subset(P1, P10, P11, lower1, upper1);
        rebalance_global(P10, P11, 0.225, 0.275);
    }

    // Final global rebalance across four parts (best-effort)
    rebalance_four(P00, P01, P10, P11, 0.225, 0.275);

    // Debug: print final weighted ratios to verify bounds
    auto s00 = subset_sum(P00);
    auto s01 = subset_sum(P01);
    auto s10 = subset_sum(P10);
    auto s11 = subset_sum(P11);
    auto ratio = [&](long s){ return (total>0)? (double)s/(double)total : 0.0; };
    std::cout << "[4-way ratios] P00=" << ratio(s00)
              << ", P01=" << ratio(s01)
              << ", P10=" << ratio(s10)
              << ", P11=" << ratio(s11) << std::endl;

    // Build partId map for cut size calculation
    std::unordered_map<Cell*, int> partId;
    for (auto* c : P00) partId[c] = 0;
    for (auto* c : P01) partId[c] = 1;
    for (auto* c : P10) partId[c] = 2;
    for (auto* c : P11) partId[c] = 3;

    int cut4 = calc_cut_size_4way(partId);

    // Output
    write_result_4way(outFile, P00, P01, P10, P11, cut4);
}

int FM::calc_cut_size_4way(const std::unordered_map<Cell*, int>& partId) {
    int cut = 0;
    for (auto& nkv : nets) {
        const Net& net = nkv.second;
        int firstPart = -1;
        bool multi = false;
        for (Cell* c : net.cells) {
            auto it = partId.find(c);
            if (it == partId.end()) continue; // should not happen
            int p = it->second;
            if (firstPart == -1) firstPart = p;
            else if (p != firstPart) { multi = true; break; }
        }
        if (multi) cut++;
    }
    return cut;
}

void FM::write_result_4way(std::string filename,
                           const std::vector<Cell*>& p0,
                           const std::vector<Cell*>& p1,
                           const std::vector<Cell*>& p2,
                           const std::vector<Cell*>& p3,
                           int cutSize) {
    startIO = clock();
    std::ofstream fout(filename);
    if (!fout.is_open()) {
        std::cerr << "Cannot open out file: " << filename << std::endl;
        return;
    }
    fout << "CutSize " << cutSize << std::endl;
    fout << "GroupA " << p0.size() << std::endl; for (auto* c : p0) fout << c->name << std::endl;
    fout << "GroupB " << p1.size() << std::endl; for (auto* c : p1) fout << c->name << std::endl;
    fout << "GroupC " << p2.size() << std::endl; for (auto* c : p2) fout << c->name << std::endl;
    fout << "GroupD " << p3.size() << std::endl; for (auto* c : p3) fout << c->name << std::endl;
    fout.close();
    timeIO += (double)(clock() - startIO) / CLOCKS_PER_SEC;

    std::cout << "[Cut size 4-way] " << cutSize << std::endl;
    std::cout << "[P0 size] " << p0.size() << ", [P1 size] " << p1.size()
              << ", [P2 size] " << p2.size() << ", [P3 size] " << p3.size() << std::endl;
}

void FM::build_local_view(const std::vector<Cell*>& subset, NetViewMap& nv) {
    nv.clear();
    size_t pinCount = 0;
    for (Cell* c : subset) {
        for (Net* n : c->nets) {
            auto& v = nv[n];
            v.pins.push_back(c);
            pinCount++;
        }
    }
    std::cout << "[local] nets=" << nv.size() << ", pins=" << pinCount << std::endl;
}

void FM::local_calc_num_in_set(NetViewMap& nv) {
    for (auto& kv : nv) {
        auto& v = kv.second;
        v.numA = 0; v.numB = 0;
        for (Cell* c : v.pins) {
            if (c->inSetA) v.numA++; else v.numB++;
        }
    }
}

void FM::local_calc_gain(const std::vector<Cell*>& subset, NetViewMap& nv) {
    for (Cell* c : subset) {
        c->gain = 0;
    }
    for (auto& kv : nv) {
        auto& v = kv.second;
        for (Cell* c : v.pins) {
            if (c->inSetA) {
                if (v.numA == 1) c->gain++;
                if (v.numB == 0) c->gain--;
            } else {
                if (v.numB == 1) c->gain++;
                if (v.numA == 0) c->gain--;
            }
        }
    }
}

void FM::local_initial_partition(const std::vector<Cell*>& subset,
                                 std::vector<Cell*>& initA,
                                 std::vector<Cell*>& initB,
                                 double lower,
                                 double upper) {
    initA.clear(); initB.clear();
    long sizeA = 0, sizeB = 0;
    long total = 0;
    for (Cell* c : subset) total += c->sizeA; // sizeA == sizeB in this input

    // Greedy by size to reach balance target
    std::vector<Cell*> order = subset;
    std::sort(order.begin(), order.end(), [](Cell* a, Cell* b){ return a->sizeA > b->sizeA; });
    for (Cell* c : order) {
        // Try place to the smaller side by current ratio
        bool placeA;
        if (sizeA <= sizeB) placeA = true; else placeA = false;
        if (placeA) {
            initA.push_back(c); sizeA += c->sizeA; c->inSetA = true;
        } else {
            initB.push_back(c); sizeB += c->sizeB; c->inSetA = false;
        }
    }

    // Tweak last few to satisfy bounds if needed
    // Simple local adjustment: move from larger side to smaller until within bounds
    auto ratio_ok = [&](long a,long b){ return is_balanced(a,b,lower,upper); };
    int guard = 0;
    while (!ratio_ok(sizeA, sizeB) && guard < (int)subset.size()) {
        if (sizeA > sizeB) {
            // move one from A to B (pick smallest from A)
            auto it = std::min_element(initA.begin(), initA.end(), [](Cell* x, Cell* y){ return x->sizeA < y->sizeA; });
            if (it == initA.end()) break;
            Cell* c = *it; initA.erase(it); initB.push_back(c);
            sizeA -= c->sizeA; sizeB += c->sizeB; c->inSetA = false;
        } else {
            auto it = std::min_element(initB.begin(), initB.end(), [](Cell* x, Cell* y){ return x->sizeB < y->sizeB; });
            if (it == initB.end()) break;
            Cell* c = *it; initB.erase(it); initA.push_back(c);
            sizeB -= c->sizeB; sizeA += c->sizeA; c->inSetA = true;
        }
        guard++;
    }
}

bool FM::local_select_base_cell(BucketList& blA, BucketList& blB, Cell*& base,
                                double lower, double upper) {
    base = nullptr;
    int ka = 1, kb = 1;
    while (ka <= (int)blA.cells.size() || kb <= (int)blB.cells.size()) {
        Cell* ca = (ka <= (int)blA.cells.size()) ? blA.get_top_kth_cell(ka) : nullptr;
        Cell* cb = (kb <= (int)blB.cells.size()) ? blB.get_top_kth_cell(kb) : nullptr;
        if (ca && ca->isLocked) ca = nullptr;
        if (cb && cb->isLocked) cb = nullptr;
        long sizeA = blA.size, sizeB = blB.size;

        auto try_pick = [&](Cell* c, bool fromA)->bool{
            if (!c) return false;
            if (fromA) return is_balanced(sizeA - c->sizeA, sizeB + c->sizeB, lower, upper);
            else       return is_balanced(sizeA + c->sizeA, sizeB - c->sizeB, lower, upper);
        };

        if (ca && cb) {
            if (ca->gain >= cb->gain) {
                if (try_pick(ca, true)) { base = ca; return true; } else ka++;
                if (try_pick(cb, false)) { base = cb; return true; } else kb++;
            } else {
                if (try_pick(cb, false)) { base = cb; return true; } else kb++;
                if (try_pick(ca, true)) { base = ca; return true; } else ka++;
            }
        } else if (ca) {
            if (try_pick(ca, true)) { base = ca; return true; } else ka++;
        } else if (cb) {
            if (try_pick(cb, false)) { base = cb; return true; } else kb++;
        } else {
            ka++; kb++;
        }
    }
    return false;
}

void FM::local_update_cells_gain(Cell* base, NetViewMap& nv,
                                 BucketList& blA, BucketList& blB) {
    if (!base) return;
    base->isLocked = true;
    if (base->inSetA) {
        // simulate move A -> B
        for (Net* net : base->nets) {
            auto it = nv.find(net);
            if (it == nv.end()) continue; // net not in subset
            auto& v = it->second;

            if (v.numB == 0) {
                for (Cell* x : v.pins) {
                    if (x == base) continue;
                    x->gain++;
                    if (x->inSetA) blA.update_cell(x); else blB.update_cell(x);
                }
            } else if (v.numB == 1) {
                for (Cell* x : v.pins) {
                    if (x != base && !x->inSetA) {
                        x->gain--;
                        if (x->inSetA) blA.update_cell(x); else blB.update_cell(x);
                    }
                }
            }

            v.numA--; v.numB++;

            if (v.numA == 0) {
                for (Cell* x : v.pins) {
                    if (x == base) continue;
                    x->gain--;
                    if (x->inSetA) blA.update_cell(x); else blB.update_cell(x);
                }
            } else if (v.numA == 1) {
                for (Cell* x : v.pins) {
                    if (x != base && x->inSetA) {
                        x->gain++;
                        if (x->inSetA) blA.update_cell(x); else blB.update_cell(x);
                    }
                }
            }
        }
        blA.remove_cell(base);
        base->inSetA = false;
        // recompute base gain under local view
        base->gain = 0; // will be updated enough by neighbor updates; keep consistent
        base->isLocked = true;
        blB.insert_cell(base);
    } else {
        // simulate move B -> A
        for (Net* net : base->nets) {
            auto it = nv.find(net);
            if (it == nv.end()) continue;
            auto& v = it->second;

            if (v.numA == 0) {
                for (Cell* x : v.pins) {
                    if (x == base) continue;
                    x->gain++;
                    if (x->inSetA) blA.update_cell(x); else blB.update_cell(x);
                }
            } else if (v.numA == 1) {
                for (Cell* x : v.pins) {
                    if (x != base && x->inSetA) {
                        x->gain--;
                        if (x->inSetA) blA.update_cell(x); else blB.update_cell(x);
                    }
                }
            }

            v.numB--; v.numA++;

            if (v.numB == 0) {
                for (Cell* x : v.pins) {
                    if (x == base) continue;
                    x->gain--;
                    if (x->inSetA) blA.update_cell(x); else blB.update_cell(x);
                }
            } else if (v.numB == 1) {
                for (Cell* x : v.pins) {
                    if (x != base && x->inSetA) {
                        x->gain++;
                        if (x->inSetA) blA.update_cell(x); else blB.update_cell(x);
                    }
                }
            }
        }
        blB.remove_cell(base);
        base->inSetA = true;
        base->gain = 0;
        base->isLocked = true;
        blA.insert_cell(base);
    }
}

std::pair<int,int> FM::local_max_partial_sum(const std::vector<int>& gains) {
    int maxV = INT_MIN, sum = 0, idx = -1;
    for (int i = 0; i < (int)gains.size(); ++i) {
        sum += gains[i];
        if (sum > maxV) { maxV = sum; idx = i; }
    }
    return {maxV, idx};
}

void FM::local_reset_lock(const std::vector<Cell*>& moved) {
    for (Cell* c : moved) c->isLocked = false;
}

void FM::bipartition_subset(const std::vector<Cell*>& subset,
                            std::vector<Cell*>& outA,
                            std::vector<Cell*>& outB,
                            double lower,
                            double upper) {
    outA.clear(); outB.clear();
    if (subset.empty()) return;

    // Build local view (nets restricted to subset)
    NetViewMap nv; build_local_view(subset, nv);
    // std::cout << "[local] subset=" << subset.size() << ", nets=" << nv.size() << std::endl;

    // Initial partition within subset
    std::vector<Cell*> A, B;
    local_initial_partition(subset, A, B, lower, upper);
    // std::cout << "[local] init A=" << A.size() << ", B=" << B.size() << std::endl;

    // Bucket lists for local run
    int localMaxPin = 0;
    for (Cell* c : subset) localMaxPin = std::max(localMaxPin, c->pinNum);
    BucketList blA, blB; blA.set_bucket_size(localMaxPin); blB.set_bucket_size(localMaxPin);

    // Place into buckets according to current inSetA
    local_calc_num_in_set(nv);
    local_calc_gain(subset, nv);
    for (Cell* c : subset) {
        c->isLocked = false;
        if (c->inSetA) blA.insert_cell(c); else blB.insert_cell(c);
    }
    std::cout << "[local] buckets prepared. sizeA=" << blA.size << ", sizeB=" << blB.size
              << ", cntA=" << blA.cells.size() << ", cntB=" << blB.cells.size() << std::endl;

    // Local FM loop (bounded iterations for speed)
    std::vector<int> gains;
    std::vector<Cell*> moved;
    int iter = 0;
    int iterLimit = std::max(1, (int)(subset.size() * 0.3));
    while (true) {
        Cell* base = nullptr;
        if (!local_select_base_cell(blA, blB, base, lower, upper)) break;
        gains.push_back(base->gain);
        moved.push_back(base);
        local_update_cells_gain(base, nv, blA, blB);
        iter++;
        // simple iteration guard for huge subsets
        if (iter >= iterLimit) break;
        // time guard
        if (((clock() - startAll) / (double)CLOCKS_PER_SEC) > runtime) break;
    }
    // std::cout << "[local] moved=" << moved.size() << std::endl;

    std::pair<int,int> _ps = local_max_partial_sum(gains);
    int maxPSum = _ps.first;
    int maxIdx = _ps.second;

    // rollback (move back from the tail after maxIdx)
    if (maxPSum <= 0) {
        // rollback all
        for (int i = (int)moved.size()-1; i >= 0; --i) {
            Cell* base = moved[i];
            local_update_cells_gain(base, nv, blA, blB);
        }
    } else if (maxIdx < (int)moved.size()-1) {
        for (int i = (int)moved.size()-1; i > maxIdx; --i) {
            Cell* base = moved[i];
            local_update_cells_gain(base, nv, blA, blB);
        }
    }

    // unlock
    local_reset_lock(moved);

    // Export result sets
    for (Cell* c : subset) {
        if (c->inSetA) outA.push_back(c); else outB.push_back(c);
    }
}
