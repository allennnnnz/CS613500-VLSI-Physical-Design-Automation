#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <unordered_map>
#include <string>
#include <algorithm>
#include <cmath>
#include <ctime>
#pragma once
#include "Net.hpp"

class Net;

class Cell {
public:
    std::string name;
    std::vector<Net*> nets;
    int sizeA;
    int sizeB;
    int pinNum;//我身上連幾條net了
    int gain;
    bool inSetA;//我現在在A集合嗎
    bool isLocked;

    Cell();//不給參數時怎麼建物件
    Cell(std::string n, int s);//給參數時怎麼建物件
    void add_net(Net* pNet);
    void add_gain();
    void sub_gain();
    void calc_gain();
    void print();
};


//big cell wont be palced at the front of the bucket list cus when we move big cell it will acffect balance more
//so we want to move small cell first