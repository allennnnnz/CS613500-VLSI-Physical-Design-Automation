#include "BucketList.hpp"

BucketList::BucketList() {
    buckets = std::vector<std::vector<Cell*>>{};
    cells = std::unordered_map<Cell*, std::pair<int, int>>{};
    maxPinNum = 0;
    maxGain = INT_MIN;
    size = 0;
};

void BucketList::set_bucket_size(int mpn) {
    maxPinNum = mpn;
    buckets.clear();
    buckets.resize(2 * mpn + 1);
    // reset state
    maxGain = -maxPinNum;
    cells.clear();
    size = 0;
}

void BucketList::insert_cell(Cell* cell) {//輸入要插入的cell物件
    // Insert cell to the bucket list and map
    int gain = cell->gain;
    // clamp gain to valid range to avoid out-of-range bucket access
    if (gain > maxPinNum) gain = maxPinNum;
    if (gain < -maxPinNum) gain = -maxPinNum;
    int bIndex = gain_to_index(gain);
    buckets[bIndex].push_back(cell);//把cell放到對應gain的bucket裡
    cells[cell] = std::make_pair(bIndex, buckets[bIndex].size() - 1);//第一個值是bucket index(gain值) 第二個值是cell在cell list裡的位置

    // Update max gain
    if(!cell->isLocked && gain > maxGain)
        maxGain = gain;

    // Update set size
    if(cell->inSetA)
        size += cell->sizeA;
    else
        size += cell->sizeB;
}

void BucketList::remove_cell(Cell* cell) {
    // Remove cell from bucket list and map
    //cells[cell] = (bIndex, cIndex)
    auto itc = cells.find(cell);
    if (itc == cells.end()) {
        // cell not tracked; nothing to do (defensive)
        return;
    }
    int bIndex = itc->second.first;
    int cIndex = itc->second.second;
    Cell* lastCell = buckets[bIndex].back();
    buckets[bIndex][cIndex] = lastCell;
    buckets[bIndex].pop_back();
    // update mapping for the swapped-in element if it wasn't the same as removed
    if (lastCell != cell) {
        cells[lastCell] = std::make_pair(bIndex, cIndex);
    }
    cells.erase(cell);

    // 調整 maxGain，避免越界
    if (cells.empty()) {
        maxGain = -maxPinNum; // keep within range when empty
    } else {
        // clamp to range first
        if (maxGain > maxPinNum) maxGain = maxPinNum;
        if (maxGain < -maxPinNum) maxGain = -maxPinNum;
        int gi = gain_to_index(maxGain);
        while (maxGain >= -maxPinNum && gi >= 0 && gi < (int)buckets.size() && buckets[gi].empty()) {
            maxGain--;
            gi = gain_to_index(maxGain);
        }
        if (maxGain < -maxPinNum) maxGain = -maxPinNum;
    }

    // Update set size
    if(cell->inSetA)
        size -= cell->sizeA;
    else
        size -= cell->sizeB;
}

//殼能搬了cell後其他的cell gain值可能會變，remove cell再insert可以同時更新bucket list和map
void BucketList::update_cell(Cell* cell) {
    remove_cell(cell);
    insert_cell(cell);
}

int BucketList::gain_to_index(int gain) {//gain值可能是負的但vector不能存負的index
    return gain + maxPinNum;
}

void BucketList::print(char setName) {
    std::cout << std::endl;
    std::cout << "Set[" << setName << "]" << std::endl;
    std::cout << "size: " << size << std::endl;
    std::cout << "Max gain: " << maxGain << std::endl;
    for(int i = 0; i < buckets.size(); i++) {
        std::cout << "gain " << i - maxPinNum << ": ";
        for(int j = 0; j < buckets[i].size(); j++) {
            std::cout << buckets[i][j]->name << " ";
        }
        std::cout << std::endl;
    }
    std::cout << std::endl;
}

//一開始是取最大gain的cell，但有時候最大gain的cell被鎖住了所以要取次大的甚至往後曲
Cell* BucketList::get_top_kth_cell(int k) {
    int gain = maxGain;
    // clamp gain to valid range
    if (gain > maxPinNum) gain = maxPinNum;
    if (gain < -maxPinNum) gain = -maxPinNum;
    int bIndex = gain_to_index(gain);
    int bSize = buckets[bIndex].size();//目前這個bucket裡有幾個cell
    while(k >= 1 && gain >= -maxPinNum) {
        if(bSize >= k) {
            return buckets[bIndex][bSize - k];
        } else {
            k -= bSize;
            gain--;
            if (gain < -maxPinNum) break;
            bIndex = gain_to_index(gain);
            bSize = buckets[bIndex].size();
        }
    }
    return nullptr;
}
