#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <unordered_map>
#include <string>
#include <algorithm>
#include <cmath>
#include <ctime>
#pragma once
#include "Cell.hpp"

class Cell;//這裡沒有先宣告會錯誤

class Net {
public:
    std::string name;
    std::vector<Cell*> cells;
    int numInSetA, numInSetB;//這條net裡面有幾個cell在A集合/幾個在B集合

    Net();
    Net(std::string n, std::vector<Cell*> cs);
    void calc_num_in_set();
    void print();
};
