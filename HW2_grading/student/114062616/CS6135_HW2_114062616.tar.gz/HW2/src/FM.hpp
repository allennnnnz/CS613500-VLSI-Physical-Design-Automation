#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <unordered_map>
#include <string>
#include <algorithm>
#include <cmath>
#include <ctime>
#include <climits>
#include "Net.hpp"
#include "Cell.hpp"
#include "BucketList.hpp"

class FM {
public:
    FM();
    FM(std::string filename, std::string outFile);
    FM(std::string filename, std::string outFile, int way);

private:
    // ===== Core data =====
    std::unordered_map<std::string, Net> nets;
    std::unordered_map<std::string, Cell> cells;
    std::vector<Cell*> selectedBaseCells;
    std::vector<int> maxGains;
    BucketList setA, setB;
    Cell* baseCell;
    int maxPinNum = -2147483648;
    int maxPartialSum;
    int maxPartialSumIndex;
    clock_t startAll, startIO;
    double timeTotal, timeCPU, timeIO;
    double runtime;
    int pass_num;

    // ===== 2-way global helpers (existing) =====
    void print_cells();
    void print_nets();
    void read_inputs(std::string filename);
    void write_result(std::string filename);
    void initial_partition();
    void initial_partition_v2();
    bool is_balanced(long sizeA, long sizeB);
    bool is_balanced(long sizeA, long sizeB, double lower, double upper);
    bool select_base_cell();
    bool select_base_cell_v2();
    bool select_base_cell_v3();
    bool select_base_cell_v4();
    void calc_max_partial_sum();
    void update_cells_gain();
    void run_pass();
    void reset_lock();
    void print_sets();
    void pause();
    void print_selected_base_cells();
    void roll_back_from(int index);
    int calc_cut_size();
    void print_time_info();
    void set_runtime();

    // ===== 4-way via recursive 2-way =====
    // Local view of a net restricted to a subset
    struct LocalNetView {
        std::vector<Cell*> pins; // cells in this subset connected to the net
        int numA = 0;            // pins on A side within subset
        int numB = 0;            // pins on B side within subset
    };
    using NetViewMap = std::unordered_map<Net*, LocalNetView>;

    // Top-level 4-way partition pipeline
    void partition_4way(std::string outFile);
    int calc_cut_size_4way(const std::unordered_map<Cell*, int>& partId);
    void write_result_4way(std::string filename,
                           const std::vector<Cell*>& p0,
                           const std::vector<Cell*>& p1,
                           const std::vector<Cell*>& p2,
                           const std::vector<Cell*>& p3,
                           int cutSize);

    // Local 2-way on a subset (does not mutate global nets' numInSetA/B)
    void bipartition_subset(const std::vector<Cell*>& subset,
                            std::vector<Cell*>& outA,
                            std::vector<Cell*>& outB,
                            double lower = 0.45,
                            double upper = 0.55);

    // Local helpers
    void build_local_view(const std::vector<Cell*>& subset, NetViewMap& nv);
    void local_initial_partition(const std::vector<Cell*>& subset,
                                 std::vector<Cell*>& initA,
                                 std::vector<Cell*>& initB,
                                 double lower,
                                 double upper);
    void local_calc_num_in_set(NetViewMap& nv);
    void local_calc_gain(const std::vector<Cell*>& subset, NetViewMap& nv);
    bool local_select_base_cell(BucketList& blA, BucketList& blB, Cell*& base,
                                double lower, double upper);
    void local_update_cells_gain(Cell* base, NetViewMap& nv,
                                 BucketList& blA, BucketList& blB);
    void local_reset_lock(const std::vector<Cell*>& moved);
    std::pair<int,int> local_max_partial_sum(const std::vector<int>& gains);
};
