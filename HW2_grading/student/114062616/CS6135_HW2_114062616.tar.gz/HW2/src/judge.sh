#!/bin/bash
cd ../..
tar -zcvf HW2_grading/student/111062625/CS6135_HW2_111062625.tar.gz HW2/
cd HW2_grading
bash HW2_grading.sh
